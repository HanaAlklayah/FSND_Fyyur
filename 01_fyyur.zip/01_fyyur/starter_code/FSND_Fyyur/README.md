# FSND_Fyyur
This is the first project of the web development course full stack non-degree "FSND" from Misk Academy, Droob on Udacity platform.
